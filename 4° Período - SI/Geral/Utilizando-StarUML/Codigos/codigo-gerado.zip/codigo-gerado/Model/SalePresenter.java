
import java.io.*;
import java.util.*;

/**
 * 
 */
public interface SalePresenter {

    /**
     * @param sale 
     * @return
     */
    void show(Sale sale);

}