
import java.io.*;
import java.util.*;

/**
 * 
 */
public class ConsoleSalePresenter implements SalePresenter {

    /**
     * Default constructor
     */
    public ConsoleSalePresenter() {
    }

    /**
     * @param sale 
     * @return
     */
    public void show(Sale sale) {
        // TODO implement here
        return null;
    }

    /**
     * @param sale 
     * @return
     */
    void show(Sale sale) {
        // TODO implement SalePresenter.show() here
        return null;
    }

}