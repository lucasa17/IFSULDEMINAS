
import java.io.*;
import java.util.*;

/**
 * 
 */
public class SaleItem {

    /**
     * Default constructor
     */
    public SaleItem() {
    }

    /**
     * 
     */
    private int amount;


    /**
     * 
     */
    private Product product;

    /**
     * @param product 
     * @param amount
     */
    public SaleItem(Product product, int amount) {
        // TODO implement here
    }

    /**
     * @return
     */
    public int getAmount() {
        // TODO implement here
        return 0;
    }

    /**
     * @return
     */
    public Product getProduct() {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public double getTotalAmount() {
        // TODO implement here
        return 0.0d;
    }

}