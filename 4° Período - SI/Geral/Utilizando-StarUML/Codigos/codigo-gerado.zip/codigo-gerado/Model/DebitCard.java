
import java.io.*;
import java.util.*;

/**
 * 
 */
public class DebitCard implements Payment {

    /**
     * Default constructor
     */
    public DebitCard() {
    }

    /**
     * 
     */
    private double discount;

    /**
     * @param discount
     */
    public DebitCard(double discount) {
        // TODO implement here
    }

    /**
     * @param value 
     * @return
     */
    public double valueToBePaid(double value) {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public String toString() {
        // TODO implement here
        return "";
    }

    /**
     * @param value 
     * @return
     */
    double valueToBePaid(double value) {
        // TODO implement Payment.valueToBePaid() here
        return 0.0d;
    }

}