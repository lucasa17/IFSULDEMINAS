
import java.io.*;
import java.util.*;

/**
 * 
 */
public interface Payment {


    /**
     * @param value 
     * @return
     */
    double valueToBePaid(double value);

}