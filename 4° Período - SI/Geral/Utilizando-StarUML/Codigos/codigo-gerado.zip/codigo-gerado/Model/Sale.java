
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Sale {

    /**
     * Default constructor
     */
    public Sale() {
    }

    /**
     * 
     */
    private Set<SaleItem> items;

    /**
     * 
     */
    private Payment payment;

    /**
     * 
     */
    public Sale() {
        // TODO implement here
    }

    /**
     * @param code 
     * @param qtde 
     * @return
     */
    public boolean addItem(String code, int qtde) {
        // TODO implement here
        return false;
    }

    /**
     * @return
     */
    public double getTotalAmount() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public Set<SaleItem> getItems() {
        // TODO implement here
        return null;
    }

    /**
     * @param paymentMethod 
     * @return
     */
    public void createPayment(String paymentMethod) {
        // TODO implement here
        return null;
    }

    /**
     * @return
     */
    public double valueToBePaid() {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public String paymentMethod() {
        // TODO implement here
        return "";
    }

}