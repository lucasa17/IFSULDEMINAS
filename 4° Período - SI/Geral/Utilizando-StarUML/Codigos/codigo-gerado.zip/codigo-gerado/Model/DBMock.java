
import java.io.*;
import java.util.*;

/**
 * 
 */
public class DBMock {

    /**
     * Default constructor
     */
    public DBMock() {
    }

    /**
     * 
     */
    private static final Map products;

    /**
     * 
     */
    private static final Map payments;

    /**
     * @param code 
     * @return
     */
    public static Set<String> selectProduct(String code) {
        // TODO implement here
        return null;
    }

    /**
     * @param code 
     * @return
     */
    public static Payment selectPayment(String code) {
        // TODO implement here
        return null;
    }

}