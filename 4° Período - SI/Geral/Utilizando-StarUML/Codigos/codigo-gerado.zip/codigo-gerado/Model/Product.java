
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Product {

    /**
     * Default constructor
     */
    public Product() {
    }

    /**
     * 
     */
    private String code;

    /**
     * 
     */
    private String description;

    /**
     * 
     */
    private double price;


    /**
     * @param code
     */
    public Product(String code) {
        // TODO implement here
    }

    /**
     * @return
     */
    public String getCode() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public String getDescription() {
        // TODO implement here
        return "";
    }

    /**
     * @return
     */
    public double getPrice() {
        // TODO implement here
        return 0.0d;
    }

}