
import java.io.*;
import java.util.*;

/**
 * 
 */
public class CreditCard implements Payment {

    /**
     * Default constructor
     */
    public CreditCard() {
    }

    /**
     * 
     */
    private double fees;

    /**
     * @param fees
     */
    public CreditCard(double fees) {
        // TODO implement here
    }

    /**
     * @param value 
     * @return
     */
    public double valueToBePaid(double value) {
        // TODO implement here
        return 0.0d;
    }

    /**
     * @return
     */
    public String toString() {
        // TODO implement here
        return "";
    }

    /**
     * @param value 
     * @return
     */
    double valueToBePaid(double value) {
        // TODO implement Payment.valueToBePaid() here
        return 0.0d;
    }

}